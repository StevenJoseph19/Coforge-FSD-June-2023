package com.mycompany.tollintake;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TollIntakeApplicationTests {

	@Test
	void contextLoads() {
	}

}
