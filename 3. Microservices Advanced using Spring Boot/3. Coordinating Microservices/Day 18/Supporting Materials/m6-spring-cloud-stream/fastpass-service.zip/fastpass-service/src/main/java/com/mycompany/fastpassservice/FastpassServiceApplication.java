package com.mycompany.fastpassservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FastpassServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(FastpassServiceApplication.class, args);
	}

}
